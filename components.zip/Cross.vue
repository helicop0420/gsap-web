<template>
	<div id="cross-wrapper">
		
		<div class="cross-container">
			<div class="flex justify-center cross-left" style="background-color: #F7AF8E; width: 40%;">
				<div class="cross-section1" id="cross-section1">
					<img src="../assets/img/cross/Lock_grip_2_new.png" id="verticalBiotronik" class="cross-left-dilator-body"/>
					<img src="../assets/img/cross/Dilator.png" class="cross-left-dilator"/>
				</div>
			</div>
			<div class="cross-right" style="width: 60%;">
				<div class="cross-right-1 cross-right-item">
					<div class="cross-dilator">
						<div style="display: table;">
							<p class="text-white cross-header">Support Catheter + Dilator</p>
						</div>
						<img src="../assets/img/cross/Lock grip 1.png" />
						<div class="flex justify-center items-center mt-20">
							<div>
								<p class="cross-content" style="font-weight: bold;">Easy-to-use Lock Grip</p>
								<p class="cross-content">Seals and secures for accurate</p>
								<p class="cross-content">positioning of Oscar Dilator,</p>
								<p class="cross-content">Oscar PTA Ballon or guide wire.</p>
							</div>
						</div>
					</div>
				</div>
				<div class="cross-right-2 cross-right-item flex items-center">
					<div class="cross-support">
						<img src="../assets/img/cross/Braided support Cath X2.png" style="padding-left: 20px; height: 200px;" />
						<div class="flex justify-center items-center mt-20" style="padding-left: 30%;">
							<div>
								<p class="text-white" style="font-weight: bold; font-size: 50px; line-height: 50px;">Cross</p>
								<p class="text-white" style="font-weight: bold; font-size: 35px; line-height: 40px;">Braided Support Catheter</p>
								<p class="text-white" style="font-weight: bold; font-size: 35px; line-height: 40px;">and Extendable Dilator</p>
								<p class="text-white" style="font-size: 35px;line-height: 40px;">Position 0:</p>
								<p class="text-white" style="font-size: 35px;line-height: 40px;">Strongest support level</p>
							</div>
						</div>
					</div>
				</div>
				<div class="cross-right-3 cross-right-item flex items-center">
					<div class="cross-support-2">
						<img src="../assets/img/cross/Braided support Cath X2.png" style="padding-left: 20px; height: 200px;" />
						<div class="flex justify-center items-center mt-20" style="padding-left: 30%;">
							<div>
								<p class="text-white" style="font-weight: bold; font-size: 50px; line-height: 50px;">Cross</p>
								<p class="text-white" style="font-weight: bold; font-size: 35px; line-height: 40px;">Braided Support Catheter</p>
								<p class="text-white" style="font-weight: bold; font-size: 35px; line-height: 40px;">and Extendable Dilator</p>
								<p class="text-white" style="font-size: 35px;line-height: 40px;">Position Contrast:</p>
								<p class="text-white" style="font-size: 35px;line-height: 40px;">Slightly extended dilator tip</p>
								<p class="text-white" style="font-size: 35px;line-height: 40px;">allows local contrast injection</p>
							</div>
						</div>
					</div>
				</div>
				<div class="cross-right-4 cross-right-item">
					<div class="cross-curved">
						<div class="flex justify-end items-center">
							<img src="../assets/img/cross/curved.jpg" style="width: 80%; max-width: 758px;"/>
						</div>
						<div class="flex justify-start items-center mt-20" style="padding-left: 100px;">
							<div>
								<p class="font-orange font-bold text-[50px]" style="font-weight: bold; font-size: 50px; line-height: 50px;">Cross</p>
								<p class="font-grey" style="font-weight: bold; font-size: 35px; line-height: 40px;">Extended Dilator</p>
								<p class="font-grey" style="font-size: 35px;line-height: 40px;">Position Max Flex:</p>
								<p class="font-grey" style="font-size: 35px;line-height: 40px;">Most flexible support level</p>
								<p class="font-grey" style="font-size: 35px;line-height: 40px;">with fully extended dilator</p>
							</div>
						</div>
					</div>
				</div>
				<!-- <div class="cross-right-5 cross-right-item">
					<p class="font-orange" style="font-size: 40px;">Achieve the pushability of an 0.035"</p>
					<p class="font-orange" style="font-size: 40px;">system on an 0.018" platform*</p>
				</div> -->

			</div>
		
		</div>
	</div>
</template>
  
<style>
	.cross-right-item {
		height: 100vh;	
	}
	.cross-left {
		position: relative;
		height: 100vh;
	}
	.cross-section1 {
		position: fixed;
		top: 100vh;
		height: 140vh;
		z-index: 200;
		left: 0;
		right: 60%;
	}
	.cross-left-dilator-body {
		height: 140vh;
		position: absolute;
		top: 0;
		left: 50%;
		z-index: 200;
		transform: translateX(-50%);
	}
	.cross-left-dilator {
		position: absolute;
		z-index: 100;
		bottom: -120px;
		height: 36vh;
		left: 50%;
		transform: translateX(-50%);
	}
	.cross-content {
		color: white;
		font-size: 35px;
		line-height: 40px;
	}
	
	.cross-header {
		border: solid 2px; 
		border-width: 2px 0 0 0; 
		padding-right: 100px; 
		font-size: 40px;
		margin-top: 100px;
		margin-left: 70px;
		font-weight: bold;
	}
	.cross-container {
		display: flex;
		height: 500vh;
		align-items: stretch;
		position: relative;
	}

	.cross-dilator {
		position: absolute;
		top: 100vh;
	}

	.cross-right-1 {
		background-color: #EF5923; 
	}
	.cross-right-2 {
		background-color: #F57853;
	}
	.cross-right-3 {
		background-color: #ED6C23;
	}
	.cross-right-4 {
		background-color: white;
	}
	.cross-right-5 {
		background-color: white;
	}
	.cross-right-item {
		height: 100vh;
	}

	.cross-right, .cross-left {
		height: 600vh;
	}

	.cross-support, .cross-support-2, .cross-curved {
		opacity: 0;
	}
</style>
  
<script>
  import gsap from 'gsap'
  import lottie from 'lottie-web'
  // var ScrollTrigger = null;
  if (process.client) {
    var {ScrollTrigger} = require('gsap/ScrollTrigger');
    var {ScrollToPlugin} = require('gsap/ScrollToPlugin')
    gsap.registerPlugin(ScrollTrigger, ScrollToPlugin);
  }
  export default {
    // components: { lottie },
  
    data() {
      return {
       
        loading: false,
        loaded: false
      };
    },
    mounted() {
			
      gsap.timeline({
        scrollTrigger: {
          trigger: '.cross-right-1',
          start: 'top top',
          scrub: true,
					end: "bottom top",
					pin: true
          // ease: gsap.Power3.easeOut
        }
      })
			.add('move')
			.to(".cross-section1", {top: 0, duration: 1 }, "move")
  		.to(".cross-dilator", { top: 0, duration: 1 }, "move")
     
			gsap.timeline({
				scrollTrigger: {
					trigger: '.cross-right-2',
					start: 'top bottom',
					end: 'top top',
					scrub: true,
					// ease: gsap.Power3.easeOut
				}
			})
			.add("dialtor-move-1")
			.to(".cross-section1", {top: '-100vh', duration: 1 }, "dialtor-move-1")

			gsap.timeline({
				scrollTrigger: {
					trigger: '.cross-right-2',
					start: 'top center',
					end: 'top top',
					scrub: true,
					// ease: gsap.Power3.easeOut
				}
			})
			.add("dialtor-move-1")
			.to(".cross-support", {opacity: 1, duration: 1}, "dialtor-move-1")
		

			gsap.timeline({
				scrollTrigger: {
					trigger: '.cross-right-3',
					start: 'top bottom',
					end: 'top top',
					scrub: true,
				}
			})
			.add("dialtor-move-2")
			.to(".cross-left-dilator", {bottom: '-180px', duration: 1}, "dialtor-move-2")

			gsap.timeline({
				scrollTrigger: {
					trigger: '.cross-right-3',
					start: 'top center',
					end: 'top top',
					scrub: true,
				}
			})
			.add("dialtor-move-2")
			.to(".cross-support-2", {opacity: 1, duration: 1}, "dialtor-move-2")
			

			gsap.timeline({
				scrollTrigger: {
					trigger: '.cross-right-4',
					start: 'top bottom',
					end: 'top top',
					scrub: true,
				}
			})
			.add("dialtor-move-3")
			.to(".cross-left-dilator", {bottom: '-30vh', duration: 1}, "dialtor-move-3")

			gsap.timeline({
				scrollTrigger: {
					trigger: '.cross-right-4',
					start: 'top center',
					end: 'top top',
					scrub: true,
				}
			})
			.add("dialtor-move-3")
			.to(".cross-curved", {opacity: 1, duration: 1}, "dialtor-move-3")
			.to(".cross-left-dilator", {bottom: '-30vh', duration: 1}, "dialtor-move-3")

			gsap.timeline({
				scrollTrigger: {
					trigger: '.cross-right-4',
					start: 'top top',
					end: 'bottom top',
					scrub: true,
				}
			})
			.to(".cross-section1", {top: '-200vh'})
    },
    
    watch: {
  
    },
    methods: {
     
     
    }
  
    
  };
  
  
  
</script>
  
  
  
  